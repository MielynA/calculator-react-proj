import React from 'react';

const test = (e) => {
    console.log(e)
    console.log(e.currentTarget.value);
    
   }

const TheButtons = (props) => {
   
    if (props.orange) {
        return (
            <button className="button col col-3 orange" style={{ minHeight: '60px' }} >{props.name}</button>
        );
    }
    else if(props.big){
        return (
            <button className="button col col-6 " style={{ minHeight: '60px' }}>{props.name}</button>
        );
    }
    else {
        return (
            <button className="button col col-3 " style={{ minHeight: '60px' }} onClick={test}>{props.name}</button>
        );
    }
}



class Buttons extends React.Component {
    constructor(props){
        super(props);

    }

   
    render(){

    return (
        <>
      <div className="row">
      <TheButtons name="AC" />
      <TheButtons name="%" />
      <TheButtons name="±" />
      <TheButtons name="÷" orange = "true"/>
      </div>

      <div className="row">
      <TheButtons name="7" />
      <TheButtons name="8" />
      <TheButtons name="9" />
      <TheButtons name="X" orange = "true"/>
      </div>
     

      <div className="row">
      <TheButtons name="4" onClick={this.test} />
      <TheButtons name="5" />
      <TheButtons name="6" />
      <TheButtons name="-" orange = "true"/>
      </div>
      
      <div className="row">
      <TheButtons name="1" />
      <TheButtons name="2" />
      <TheButtons name="3" />
      <TheButtons name="+" orange = "true"/>
      </div>

      <div className="row">
      <TheButtons name="0" big="true" />
      <TheButtons name="." />
      <TheButtons name="=" orange = "true"/>
      </div>
        </>
    );

}
}


export default Buttons