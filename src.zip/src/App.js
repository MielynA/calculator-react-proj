import React, { Component } from 'react';
import Screen from './components/Screen';
import Buttons from './components/Buttons';

class App extends Component {
  constructor(props){
    super(props);
    this.state = { 
       displayValue: '0',
       previousValue: null, 
       operation: null,
       waitingForNewValue: false
    }
  }
   

  valueClicked = (e) =>{
    console.log(e.target.value)
    if(this.state.displayValue === 0){
     this.setState({displayValue: e.name})
    }
    else {
      let newValue = this.state.displayValue;
      newValue += e.name
      this.setState({displayValue: newValue})
    }
    
  }
  test = (displayValue) => {
    const {newValue} = this.state;
    newValue.unshift({displayValue});
    this.setState({ displayValue: newValue });
  }
  
  render() {
    console.log(this.state.displayValue)
    return (
      <div className="container" style={{width: '50%'}}>
      <Screen displayValue={this.state.displayValue}/>
      
      <Buttons displayValue={this.test}/>

      </div>
    );

  }
}

export default App;
